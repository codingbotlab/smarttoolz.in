<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/auth/config.php';

function learning_pdo(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $host = defined('DB_HOST') ? DB_HOST : 'localhost';
    $name = defined('DB_NAME') ? DB_NAME : (defined('DB_DATABASE') ? DB_DATABASE : '');
    $user = defined('DB_USER') ? DB_USER : (defined('DB_USERNAME') ? DB_USERNAME : '');
    $pass = defined('DB_PASS') ? DB_PASS : (defined('DB_PASSWORD') ? DB_PASSWORD : '');

    if ($name === '' || $user === '') {
        throw new RuntimeException('Database constants are missing in auth/config.php.');
    }

    $pdo = new PDO(
        "mysql:host={$host};dbname={$name};charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
    return $pdo;
}

function learning_user_id(): int {
    return (int)($_SESSION['user_id'] ?? 0);
}

function learning_require_login(): void {
    if (function_exists('requireLogin')) {
        requireLogin();
        return;
    }
    if (learning_user_id() < 1) {
        header('Location: /creator-ai/auth/login');
        exit;
    }
}

function learning_current_user(): array {
    $uid=learning_user_id();
    if (function_exists('getCreatorUser')) {
        $u=getCreatorUser($uid);
        if (is_array($u)) return $u;
    }
    return ['id'=>$uid,'name'=>(string)($_SESSION['user_name']??'Creator'),'avatar'=>(string)($_SESSION['user_avatar']??'')];
}

function eh(mixed $v): string {
    return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');
}

function learning_course(string $slug): ?array {
    $s=learning_pdo()->prepare("SELECT * FROM learning_courses WHERE slug=? AND is_published=1 LIMIT 1");
    $s->execute([$slug]);
    return $s->fetch()?:null;
}

function learning_modules(int $courseId): array {
    $s=learning_pdo()->prepare("SELECT * FROM learning_modules WHERE course_id=? ORDER BY sort_order");
    $s->execute([$courseId]);return $s->fetchAll();
}

function learning_course_stats(int $courseId,int $uid): array {
    $p=learning_pdo();
    $s=$p->prepare("SELECT COUNT(l.id) total,COUNT(CASE WHEN lp.completed=1 THEN 1 END) done FROM learning_modules m LEFT JOIN learning_lessons l ON l.module_id=m.id AND l.is_published=1 LEFT JOIN learning_lesson_progress lp ON lp.lesson_id=l.id AND lp.user_id=? WHERE m.course_id=?");
    $s->execute([$uid,$courseId]);$r=$s->fetch()?:[];
    $total=(int)($r['total']??0);$done=(int)($r['done']??0);
    $x=$p->prepare("SELECT COALESCE(SUM(xp_earned),0) FROM learning_quiz_attempts a JOIN learning_quizzes q ON q.id=a.quiz_id WHERE a.user_id=? AND q.course_id=?");
    $x->execute([$uid,$courseId]);
    return ['total'=>$total,'done'=>$done,'percent'=>$total?round($done*100/$total):0,'xp'=>(int)$x->fetchColumn()];
}

function learning_bootstrap_activity(int $uid,string $type,int $courseId=null,int $lessonId=null):void {
    try {
        $s=learning_pdo()->prepare("INSERT INTO learning_activity(user_id,activity_type,course_id,lesson_id) VALUES(?,?,?,?)");
        $s->execute([$uid,$type,$courseId,$lessonId]);
    } catch(Throwable $e) { error_log($e->getMessage()); }
}

function learning_courses_with_progress(int $uid): array {
    $s=learning_pdo()->prepare("SELECT c.*,COUNT(l.id) lessons,COUNT(CASE WHEN p.completed=1 THEN 1 END) done,CASE WHEN COUNT(l.id)=0 THEN 0 ELSE ROUND(COUNT(CASE WHEN p.completed=1 THEN 1 END)*100/COUNT(l.id)) END percent FROM learning_courses c LEFT JOIN learning_modules m ON m.course_id=c.id LEFT JOIN learning_lessons l ON l.module_id=m.id AND l.is_published=1 LEFT JOIN learning_lesson_progress p ON p.lesson_id=l.id AND p.user_id=? WHERE c.is_published=1 GROUP BY c.id ORDER BY c.sort_order,c.id");
    $s->execute([$uid]);return $s->fetchAll();
}
