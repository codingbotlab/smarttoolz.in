<?php
const LEARNING_LANGUAGE = 'java';
require __DIR__ . '/../common/quiz-run.php';
