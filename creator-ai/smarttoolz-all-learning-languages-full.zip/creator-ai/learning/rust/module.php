<?php
const LEARNING_LANGUAGE = 'rust';
require __DIR__ . '/../common/module.php';
